CREATE TRIGGER return_trigger
AFTER DELETE ON purchase
FOR EACH ROW
  BEGIN
    UPDATE employee SET totalnum = totalnum - 1 WHERE eid = (SELECT eid FROM sale WHERE sid = OLD.sid);
    UPDATE employee SET totalprofit = totalprofit - (SELECT profit FROM sale WHERE sale.sid = OLD.sid) WHERE
      eid = (SELECT eid FROM sale WHERE sid = OLD.sid);
    UPDATE car SET quantity= quantity - 1 WHERE carid = (SELECT  carid FROM sale WHERE sale.sid = OLD.sid);
  END;
