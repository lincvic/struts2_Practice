CREATE TRIGGER purchase_trigger
AFTER INSERT ON purchase
FOR EACH ROW
  BEGIN
    UPDATE employee SET totalnum = totalnum + 1 WHERE eid = (SELECT eid FROM sale WHERE sid = NEW.sid);
    UPDATE employee SET totalprofit = totalprofit + (SELECT profit FROM sale WHERE sale.sid = NEW.sid) WHERE 
      eid = (SELECT eid FROM sale WHERE sid = NEW.sid);
    UPDATE car SET quantity= quantity + 1 WHERE carid = (SELECT  carid FROM sale WHERE sale.sid = NEW.sid);
  END;
