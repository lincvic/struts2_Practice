CREATE VIEW purchase_detail AS
  SELECT
    `carsalesmanagementsystem`.`purchase`.`pid`          AS `pid`,
    `carsalesmanagementsystem`.`client`.`clientid`       AS `clientid`,
    `carsalesmanagementsystem`.`client`.`name`           AS `cname`,
    `detail_sale`.`sid`                                  AS `sid`,
    `detail_sale`.`eid`                                  AS `eid`,
    `detail_sale`.`name`                                 AS `ename`,
    `detail_sale`.`carid`                                AS `carid`,
    `detail_sale`.`brand`                                AS `brand`,
    `detail_sale`.`model`                                AS `model`,
    `detail_sale`.`price`                                AS `price`,
    `detail_sale`.`profit`                               AS `profit`,
    `carsalesmanagementsystem`.`purchase`.`purchasedate` AS `purchasedate`
  FROM `carsalesmanagementsystem`.`purchase`
    JOIN `carsalesmanagementsystem`.`detail_sale`
    JOIN `carsalesmanagementsystem`.`client`
  WHERE ((`carsalesmanagementsystem`.`purchase`.`sid` = `detail_sale`.`sid`) AND
         (`carsalesmanagementsystem`.`purchase`.`clientid` = `carsalesmanagementsystem`.`client`.`clientid`));
