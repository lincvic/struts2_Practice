CREATE VIEW detail_sale AS
  SELECT
    `carsalesmanagementsystem`.`sale`.`sid`             AS `sid`,
    `carsalesmanagementsystem`.`sale`.`eid`             AS `eid`,
    `carsalesmanagementsystem`.`employee`.`name`        AS `name`,
    `carsalesmanagementsystem`.`employee`.`phonenumber` AS `phonenumber`,
    `carsalesmanagementsystem`.`employee`.`totalnum`    AS `totalnum`,
    `carsalesmanagementsystem`.`employee`.`totalprofit` AS `totalprofit`,
    `carsalesmanagementsystem`.`sale`.`carid`           AS `carid`,
    `carsalesmanagementsystem`.`car`.`brand`            AS `brand`,
    `carsalesmanagementsystem`.`car`.`model`            AS `model`,
    `carsalesmanagementsystem`.`car`.`price`            AS `price`,
    `carsalesmanagementsystem`.`car`.`picture`          AS `picture`,
    `carsalesmanagementsystem`.`car`.`quantity`         AS `quantity`,
    `carsalesmanagementsystem`.`sale`.`profit`          AS `profit`
  FROM `carsalesmanagementsystem`.`sale`
    JOIN `carsalesmanagementsystem`.`employee`
    JOIN `carsalesmanagementsystem`.`car`
  WHERE ((`carsalesmanagementsystem`.`sale`.`eid` = `carsalesmanagementsystem`.`employee`.`eid`) AND
         (`carsalesmanagementsystem`.`sale`.`carid` = `carsalesmanagementsystem`.`car`.`carid`));
